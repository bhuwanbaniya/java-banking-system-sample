package org.personal.banksystem.service.model.impl;


//bhuwanbaniya2414002
// This class read  account  information from the CSV file  and convert into  object

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import org.personal.javabanksystem.model.Account;

public class ReadingAccount {
    private String filePath;

    // Constructor to initialize the file path
    public ReadingAccount(String filePath) {
        this.filePath = filePath;
    }

    // Method to read CSV file and create a list of accounts
    public LinkedList<Account> getAccounts() {
        LinkedList<Account> accounts = new LinkedList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split line by comma and parse account details
                String[] parts = line.split(",");
                String firstName = parts[0];
                String lastName = parts[1];
                int accountNumber = Integer.parseInt(parts[2]);
                int balance = Integer.parseInt(parts[3]);
                
                // Create and add Account object to list
                accounts.add(new Account(firstName, lastName, balance, accountNumber));
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return accounts;
    }
}
