package org.personal.banksystem.model.main.GUI;
//bhuwanbaniya2414002
//This class has main method and main GUI which will run the this banking system in dynamic


import javax.swing.*;
import org.personal.banksystem.service.model.impl.ReadingAccount;
import org.personal.javabanksystem.model.Account;
import org.personal.javabanksystem.transaction.service.model.impl.Transactionserviceimpl;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class JavabankingsystemGUI {
    private JFrame frame;
    private LinkedList<Account> accountList; // List of all bank accounts
    private JTextArea accountDetailsArea; // Area to show account details
    private JPanel accountDetailsPanel; // Panel to hold the account details area

    //Constructor to set up the GUI.
    // @param accountList List of bank accounts to be managed.
    
    
    public JavabankingsystemGUI(LinkedList<Account> accountList) {
        this.accountList = accountList; // Save the list of accounts
        initialize(); // Set up the GUI components
        showWelcomeMessage(); // Show a welcome message to the user
    }

    
     //Initializes the GUI components and layout.
  
    private void initialize() {
        frame = new JFrame("Simple Banking System BBN"); // Create the main window
        frame.setBounds(100, 100, 1200, 900); // Set the size of the window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close the application when the window is closed
        frame.setLayout(null); // Set layout to null for manual positioning

        // Set up the background panel with an image
        BackgroundPanel backgroundPanel = new BackgroundPanel("src/image/bankbackground.jpg");
        backgroundPanel.setLayout(null);
        backgroundPanel.setBounds(0, 0, frame.getWidth(), frame.getHeight());

        // Add a label for the bank name
        JLabel bankNameLabel = new JLabel("BHUWAN BANK NEPAL BBN");
        bankNameLabel.setFont(new Font("Arial", Font.BOLD, 50)); // Set font size and style
        bankNameLabel.setForeground(new Color(0, 0, 128)); // Set text color
        bankNameLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center the text
        bankNameLabel.setBounds(0, 20, frame.getWidth(), 60); // Set position and size
        backgroundPanel.add(bankNameLabel);

        // Add buttons for different operations
        JButton btnViewAccount = createButton("View Account Details", "src/image/view_account.jpg", 50, 100);
        backgroundPanel.add(btnViewAccount);

        JButton btnDeposit = createButton("Deposit", "src/image/deposit.png", 50, 260);
        backgroundPanel.add(btnDeposit);

        JButton btnWithdraw = createButton("Withdraw", "src/image/withdraw.png", 50, 420);
        backgroundPanel.add(btnWithdraw);

        JButton btnTransfer = createButton("Transfer", "src/image/transfer.png", 50, 580);
        backgroundPanel.add(btnTransfer);

        // Create a panel for contact information
        JPanel contactPanel = new JPanel();
        contactPanel.setLayout(new GridLayout(2, 1)); // Arrange contact info in two rows
        contactPanel.setBackground(Color.LIGHT_GRAY);
        contactPanel.setBounds(0, frame.getHeight() - 120, frame.getWidth(), 100);
        contactPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Add padding

        // Add email and phone information to the contact panel
        JLabel emailLabel = new JLabel("Email: support@bhuwanbanknepal.com");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        emailLabel.setForeground(Color.BLACK);
        emailLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel phoneLabel = new JLabel("Telephone: +977 1-1234567");
        phoneLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        phoneLabel.setForeground(Color.BLACK);
        phoneLabel.setHorizontalAlignment(SwingConstants.CENTER);

        contactPanel.add(emailLabel);
        contactPanel.add(phoneLabel);

        frame.add(contactPanel); // Add the contact panel to the main frame

        // Create a panel to show account details
        accountDetailsPanel = new JPanel();
        accountDetailsPanel.setLayout(new BorderLayout()); // Use border layout
        accountDetailsPanel.setBounds(frame.getWidth() - 320, 100, 300, 200); // Set position and size
        accountDetailsPanel.setBorder(BorderFactory.createTitledBorder("Account Details")); // Add a border with title
        accountDetailsPanel.setVisible(false); // Hide this panel by default

        // Create a text area to display account details
        accountDetailsArea = new JTextArea();
        accountDetailsArea.setEditable(false); // Make the text area read-only
        accountDetailsArea.setFont(new Font("Arial", Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(accountDetailsArea); // Add a scroll pane
        accountDetailsPanel.add(scrollPane, BorderLayout.CENTER);

        // Add a close button to hide the account details panel
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.PLAIN, 14));
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                accountDetailsPanel.setVisible(false); // Hide the panel when the button is clicked
            }
        });
        accountDetailsPanel.add(closeButton, BorderLayout.SOUTH);

        frame.add(accountDetailsPanel); // Add the account details panel to the main frame
        frame.add(backgroundPanel); // Add the background panel to the main frame
        frame.setVisible(true); // Make the window visible
    }

    /**
     * Creates a button with the given text, icon, and position.
     * @param text The text to display on the button.
     * @param iconPath The path to the button's icon image.
     * @param x The x-coordinate of the button's position.
     * @param y The y-coordinate of the button's position.
     * @return The configured JButton.
     */
    private JButton createButton(String text, String iconPath, int x, int y) {
        JButton button = new ShadowButton(text, iconPath); // Create the button with a shadow effect
        customizeButton(button); // Customize the button's appearance
        button.setBounds(x, y, 500, 150); // Set the button's position and size
        button.setPreferredSize(new Dimension(500, 150));

        // Set up the action listener for the button
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (text.equals("View Account Details")) {
                    viewAccountDetails(); // Show account details
                } else if (text.equals("Deposit")) {
                    deposit(); // Handle deposit action
                } else if (text.equals("Withdraw")) {
                    withdraw(); // Handle withdrawal action
                } else if (text.equals("Transfer")) {
                    transfer(); // Handle transfer action
                }
                showThankYouMessage(); // Show a thank you message after the action
            }
        });
        return button;
    }

    // Customizes the appearance of a button.
    // @param button The button to customize.
    
    private void customizeButton(JButton button) {
        button.setForeground(Color.WHITE); // Set text color
        button.setFont(button.getFont().deriveFont(Font.BOLD, 30f)); // Set font size and style
        button.setBackground(Color.DARK_GRAY); // Set background color
        button.setOpaque(true); // Make sure the background color is visible
        button.setBorderPainted(false); // Remove the border

        button.setHorizontalAlignment(SwingConstants.CENTER); // Center the text horizontally
        button.setVerticalAlignment(SwingConstants.CENTER); // Center the text vertically
        button.setIconTextGap(20); // Add space between the icon and text

        // Scale the button icon to a consistent size
        ImageIcon icon = (ImageIcon) button.getIcon();
        if (icon != null) {
            Image image = icon.getImage();
            Image scaledImage = image.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(scaledImage));
        }
    }

    
    // Shows a welcome message to the user when they first open the application.
     
    private void showWelcomeMessage() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Stack components vertically
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding

        JLabel message = new JLabel("Welcome to BHUWAN BANK NEPAL BBN!");
        message.setFont(new Font("Arial", Font.BOLD, 20)); // Set font size and style
        message.setHorizontalAlignment(SwingConstants.CENTER); // Center the text
        panel.add(message);

        JLabel iconLabel = new JLabel(new ImageIcon("src/image/welcome_icon.png"));
        panel.add(iconLabel);

        // Show a dialog with the welcome message
        JOptionPane.showConfirmDialog(frame, panel, "Welcome", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
    }

    // Shows a thank you message to the user after an action is completed.
    
    private void showThankYouMessage() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Stack components vertically
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding

        JLabel message = new JLabel("Thank you for using BHUWAN BANK NEPAL BBN!");
        message.setFont(new Font("Arial", Font.BOLD, 20)); // Set font size and style
        message.setHorizontalAlignment(SwingConstants.CENTER); // Center the text
        panel.add(message);

        JLabel iconLabel = new JLabel(new ImageIcon("src/image/thank_you_icon.png"));
        panel.add(iconLabel);

        // Show a dialog with the thank you message
        JOptionPane.showConfirmDialog(frame, panel, "Thank You", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
    }

    // Displays the details of a specific account.
     
    private void viewAccountDetails() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr); // Convert input to number
            Account account = findAccount(accountNumber); // Find the account
            if (account != null) {
                // Show account details
                String details = "First Name: " + account.getFirstName() +
                                  "\nLast Name: " + account.getLastName() +
                                  "\nAccount Number: " + account.getAccountNumber() +
                                  "\nBalance: " + account.getBalance();
                accountDetailsArea.setText(details); // Display the details
                accountDetailsPanel.setVisible(true); // Show the panel
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found!"); // Error message
                accountDetailsArea.setText(""); // Clear details area
                accountDetailsPanel.setVisible(false); // Hide the panel
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!"); // Error message
        }
    }

    // Handles depositing money into an account.

    private void deposit() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr); // Convert input to number
            Account account = findAccount(accountNumber); // Find the account
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Deposit:");
                try {
                    int amount = Integer.parseInt(amountStr); // Convert input to number
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!"); // Error message
                    } else {
                        account.deposit(amount); // Deposit the money
                        JOptionPane.showMessageDialog(frame, "Deposit Successful! New Balance: " + account.getBalance());
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!"); // Error message
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found, try again!"); // Error message
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!"); // Error message
        }
    }

    // Handles withdrawing money from an account.

    
    private void withdraw() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr); // Convert input to number
            Account account = findAccount(accountNumber); // Find the account
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Withdraw:");
                try {
                    int amount = Integer.parseInt(amountStr); // Convert input to number
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!"); // Error message
                    } else if (account.getBalance() >= amount) {
                        account.withdraw(amount); // Withdraw the money
                        JOptionPane.showMessageDialog(frame, "Withdrawal Successful! New Balance: " + account.getBalance());
                    } else {
                        JOptionPane.showMessageDialog(frame, "Insufficient funds!"); // Error message
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!"); // Error message
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found, try again!"); // Error message
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!"); // Error message
        }
    }

    // Handles transferring money between two accounts.
     
    private void transfer() {
        String sourceAccountNumberStr = JOptionPane.showInputDialog("Enter Source Account Number:");
        try {
            int sourceAccountNumber = Integer.parseInt(sourceAccountNumberStr); // Convert input to number
            Account sourceAccount = findAccount(sourceAccountNumber); // Find the source account

            String destinationAccountNumberStr = JOptionPane.showInputDialog("Enter Destination Account Number:");
            int destinationAccountNumber = Integer.parseInt(destinationAccountNumberStr); // Convert input to number
            Account destinationAccount = findAccount(destinationAccountNumber); // Find the destination account

            if (sourceAccount != null && destinationAccount != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Transfer:");
                try {
                    int amount = Integer.parseInt(amountStr); // Convert input to number
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!"); // Error message
                    } else if (sourceAccount.getBalance() >= amount) {
                        // Perform the transfer
                        Transactionserviceimpl.transfer(sourceAccount, destinationAccount, amount);
                        JOptionPane.showMessageDialog(frame, "Transfer Successful!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Insufficient funds in source account!"); // Error message
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!"); // Error message
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found, try again!"); // Error message
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!"); // Error message
        }
    }

    // Finds an account by its number from the list.
    // @param accountNumber The account number to search for.
    //@return The Account object if found, otherwise null.
     
    private Account findAccount(int accountNumber) {
        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                return account; // Return the account if found
            }
        }
        return null; // Return null if the account is not found
    }

    
    // Main method to start the application.
    // @param args Command line arguments.
    
    public static void main(String[] args) {
        String filePath = "src/Accounts.csv"; // Path to the file with account data
        ReadingAccount readingAccount = new ReadingAccount(filePath); // Read accounts from the file
        LinkedList<Account> accountList = readingAccount.getAccounts(); // Get the list of accounts

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new JavabankingsystemGUI(accountList); // Create and show the GUI
                } catch (Exception e) {
                    e.printStackTrace(); // Print any errors
                }
            }
        });
    }
}
