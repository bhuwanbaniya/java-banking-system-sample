package org.personal.banksystem.model.main.GUI;

//bhuwanbaniya2414002
/*As i have extends JButton here and this 
class is to  custom  JButton  that adds a shadow effect and  custom styling  */


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;

class ShadowButton extends JButton {
    // Serial version UID for serialization compatibility
    private static final long serialVersionUID = 1L;

    // Constructor to initialize the button with text and icon
    public ShadowButton(String text, String imagePath) {
        super(text); // Call JButton's constructor with button text
        setContentAreaFilled(false); // Make button background transparent
        setFocusPainted(false); // Remove focus outline
        setHorizontalTextPosition(SwingConstants.CENTER); // Center text horizontally
        setVerticalTextPosition(SwingConstants.BOTTOM); // Position text below the icon
        setIcon(new ImageIcon(imagePath)); // Set button icon from provided image path
    }

    // Override to custom paint the button component
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create(); // Create a copy of the Graphics object

        // Draw shadow effect
        g2.setColor(Color.GRAY); // Set shadow color
        g2.fillRoundRect(5, 5, getWidth() - 1, getHeight() - 1, 15, 15); // Draw shadow rectangle with rounded corners

        // Draw button background
        g2.setColor(getBackground()); // Set button background color
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15); // Draw button rectangle with rounded corners

        g2.dispose(); // Dispose of the Graphics2D object

        super.paintComponent(g); // Call superclass method to ensure button text and icon are painted
    }

    // Override to custom paint the button border
    @Override
    protected void paintBorder(Graphics g) {
        g.setColor(getForeground()); // Set border color to button foreground color
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15); // Draw rounded border rectangle
    }
}
