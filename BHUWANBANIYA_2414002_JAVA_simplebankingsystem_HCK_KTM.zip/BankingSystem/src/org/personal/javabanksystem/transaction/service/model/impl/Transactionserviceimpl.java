
//bhuwanbaniya2414002
//This is implementation where the transaction will check the details with  static method for  transferring money

package org.personal.javabanksystem.transaction.service.model.impl;

import org.personal.javabanksystem.model.Account;

public class Transactionserviceimpl {

    // Method to transfer money from one account to another
    public static void transfer(Account fromAccount, Account toAccount, int amount) {
        // Check if the source account has enough balance for the transfer
        if (fromAccount.getBalance() >= amount) {
            // Withdraw the amount from the source account
            fromAccount.withdraw(amount);
            // Deposit the amount into the destination account
            toAccount.deposit(amount);
            // Print a confirmation message with transfer details
            System.out.println(amount + " transferred from " + fromAccount.getFirstName() + " to " + toAccount.getFirstName());
        } else {
            // Print an error message if there are insufficient funds
            System.out.println("Insufficient funds for transfer");
        }
    }
}
