//bhuwanbaniya2414002
//This is service_model
// It demonstrating basic account operations
package org.personal.javabanksystem.transaction.service.model;

import org.personal.javabanksystem.model.Account;

public class Transaction {
    public static void main(String[] args) {
        // Create two accounts with initial details
        Account account1 = new Account("Jeffrey", "Ting", 2000, 1); // Account 1 with $2000 balance
        Account account2 = new Account("Hiran", "Patel", 1000, 2); // Account 2 with $1000 balance

        // Print initial balances of both accounts
        System.out.println("Initial balances:");
        System.out.println("Account 1: $" + account1.getBalance()); // Show balance of account 1
        System.out.println("Account 2: $" + account2.getBalance()); // Show balance of account 2

        // Perform a deposit operation on account 1
        account1.deposit(250); // Add $250 to account 1
        // Perform a withdrawal operation on account 2
        account2.withdraw(500); // Subtract $500 from account 2

        // Print final balances after the transactions
        System.out.println("Final balances:");
        System.out.println("Account 1: $" + account1.getBalance()); // Show updated balance of account 1
        System.out.println("Account 2: $" + account2.getBalance()); // Show updated balance of account 2
    }
}
