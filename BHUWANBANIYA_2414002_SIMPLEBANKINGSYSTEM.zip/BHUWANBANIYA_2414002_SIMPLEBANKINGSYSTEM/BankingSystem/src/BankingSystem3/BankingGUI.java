package BankingSystem3;
//bhuwanbaniya2414002
import javax.swing.*;
import bankingSystem.Account;
import bankingSystem.Transaction;
import bankingSystem2.ReadAccounts;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class BankingGUI {
    private JFrame frame;
    private LinkedList<Account> accountList;

    public BankingGUI(LinkedList<Account> accountList) {
        this.accountList = accountList;
        initialize();
    }

    private void initialize() {
        frame = new JFrame(" Simple Banking System BBN ");
        frame.setBounds(400, 400, 700, 580);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        panel.setLayout(new FlowLayout());

        // Custom welcome message with "Next" button
        Object[] options = {"NEXT"};
        JOptionPane.showOptionDialog(frame, "Welcome to the BHUWAN BANK NEPAL BBN !", "Welcome",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

        JButton btnViewAccount = new ShadowButton("View Account Details", "D:/image/view_account.jpg");
        customizeButton(btnViewAccount);
        btnViewAccount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewAccountDetails();
            }
        });
        panel.add(btnViewAccount);

        JButton btnDeposit = new ShadowButton("Deposit", "D:/image/deposit.png");
        customizeButton(btnDeposit);
        btnDeposit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deposit();
            }
        });
        panel.add(btnDeposit);

        JButton btnWithdraw = new ShadowButton("Withdraw", "D:/image/withdraw.png");
        customizeButton(btnWithdraw);
        btnWithdraw.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                withdraw();
            }
        });
        panel.add(btnWithdraw);

        JButton btnTransfer = new ShadowButton("Transfer", "D:/image/transfer.png");
        customizeButton(btnTransfer);
        btnTransfer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                transfer();
            }
        });
        panel.add(btnTransfer);

        frame.setVisible(true);
    }

    private void customizeButton(JButton button) {
        button.setForeground(Color.BLACK); // Set text color to black
        button.setFont(button.getFont().deriveFont(Font.BOLD));
    }

    private void viewAccountDetails() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr);
            Account account = findAccount(accountNumber);
            if (account != null) {
                JOptionPane.showMessageDialog(frame, "First Name: " + account.getFirstName() +
                        "\nLast Name: " + account.getLastName() +
                        "\nAccount Number: " + account.getAccountNumber() +
                        "\nBalance: " + account.getBalance());
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private void deposit() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr);
            Account account = findAccount(accountNumber);
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Deposit:");
                try {
                    int amount = Integer.parseInt(amountStr);
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!");
                    } else {
                        account.deposit(amount);
                        JOptionPane.showMessageDialog(frame, "Deposit Successful! New Balance: " + account.getBalance());
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found tey again!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private void withdraw() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr);
            Account account = findAccount(accountNumber);
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Withdraw:");
                try {
                    int amount = Integer.parseInt(amountStr);
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!");
                    } else if (account.getBalance() >= amount) {
                        account.withdraw(amount);
                        JOptionPane.showMessageDialog(frame, "Withdrawal Successful! New Balance: " + account.getBalance());
                    } else {
                        JOptionPane.showMessageDialog(frame, "Insufficient funds!");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found try again!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private void transfer() {
        String sourceAccountNumberStr = JOptionPane.showInputDialog("Enter Source Account Number:");
        try {
            int sourceAccountNumber = Integer.parseInt(sourceAccountNumberStr);
            Account sourceAccount = findAccount(sourceAccountNumber);

            String destinationAccountNumberStr = JOptionPane.showInputDialog("Enter Destination Account Number:");
            int destinationAccountNumber = Integer.parseInt(destinationAccountNumberStr);
            Account destinationAccount = findAccount(destinationAccountNumber);

            if (sourceAccount != null && destinationAccount != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Transfer:");
                try {
                    int amount = Integer.parseInt(amountStr);
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!");
                    } else if (sourceAccount.getBalance() >= amount) {
                        Transaction.transfer(sourceAccount, destinationAccount, amount);
                        JOptionPane.showMessageDialog(frame, "Transfer Successful!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Insufficient funds in source account!");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found try again!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private Account findAccount(int accountNumber) {
        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        String filePath = "src/Accounts.csv";
        ReadAccounts readAccounts = new ReadAccounts(filePath);
        LinkedList<Account> accountList = readAccounts.getAccounts();

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    BankingGUI window = new BankingGUI(accountList);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

class ShadowButton extends JButton {
    private Image image;

    public ShadowButton(String text, String imagePath) {
        super(text);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setHorizontalTextPosition(SwingConstants.CENTER);
        setVerticalTextPosition(SwingConstants.BOTTOM);
        setIcon(new ImageIcon(imagePath));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(Color.GRAY);
        g2.fillRoundRect(5, 5, getWidth() - 1, getHeight() - 1, 15, 15);
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
        g2.dispose();

        super.paintComponent(g);
    }

    @Override
    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
    }
}
