package bankingSystem;
//bhuwanbaniya2414002
// Account.java
public class Account extends Customer {
    private int balance;
    private int accountNumber;

    // Constructor
    public Account(String firstName, String lastName, int balance, int accountNumber) {
        super(firstName, lastName);
        this.balance = balance;
        this.accountNumber = accountNumber;
    }

    // Getters
    public int getBalance() {
        return balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    // Methods
    public void deposit(int amount) {
        balance += amount;
    }

    public void withdraw(int amount) {
        if (balance >= amount) {
            balance -= amount;
        } else {
            System.out.println("Insufficient funds");
        }
    }
}
