package bankingSystem;
//bhuwanbaniya2414002
public class Transaction {
    public static void transfer(Account source, Account destination, int amount) {
        if (source.getBalance() >= amount) {
            source.withdraw(amount);
            destination.deposit(amount);
            System.out.println(amount + " transferred from " + source.getFirstName() + "'s account to " + destination.getFirstName() + "'s account");
        } else {
            System.out.println("Transfer failed: Insufficient funds in source account");
        }
    }
}