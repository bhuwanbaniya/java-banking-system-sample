package bankingSystem;
//bhuwanbaniya2414002
public class Main {
    public static void main(String[] args) {
        // Creating accounts
        Account account1 = new Account("Jeffrey", "Ting", 2000, 1);
        Account account2 = new Account("Hiran", "Patel", 1000, 2);

        // Testing
        System.out.println("Initial balance of account1: " + account1.getBalance());
        System.out.println("Initial balance of account2: " + account2.getBalance());

        account1.deposit(250);
        System.out.println("Balance of account1 after deposit: " + account1.getBalance());

        account2.withdraw(500);
        System.out.println("Balance of account2 after withdrawal: " + account2.getBalance());

        Transaction.transfer(account1, account2, 250);

        System.out.println("Final balance of account1: " + account1.getBalance());
        System.out.println("Final balance of account2: " + account2.getBalance());
    }
}
