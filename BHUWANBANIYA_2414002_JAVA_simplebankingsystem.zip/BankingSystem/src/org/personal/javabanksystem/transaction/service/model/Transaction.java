package org.personal.javabanksystem.transaction.service.model;

import org.personal.javabanksystem.model.Account;

public class Transaction {
    public static void main(String[] args) {
        Account account1 = new Account("Jeffrey", "Ting", 2000, 1);
        Account account2 = new Account("Hiran", "Patel", 1000, 2);

        System.out.println("Initial balances:");
        System.out.println("Account 1: $" + account1.getBalance());
        System.out.println("Account 2: $" + account2.getBalance());

        // Perform a deposit and a withdrawal
        account1.deposit(250);
        account2.withdraw(500);

        System.out.println("Final balances:");
        System.out.println("Account 1: $" + account1.getBalance());
        System.out.println("Account 2: $" + account2.getBalance());
    }
}
