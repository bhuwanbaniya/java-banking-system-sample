package org.personal.javabanksystem.transaction.service.model.impl;

import org.personal.javabanksystem.model.Account;

public class Transactionserviceimpl {
    public static void transfer(Account fromAccount, Account toAccount, int amount) {
        if (fromAccount.getBalance() >= amount) {
            fromAccount.withdraw(amount);
            toAccount.deposit(amount);
            System.out.println(amount + " transferred from " + fromAccount.getFirstName() + " to " + toAccount.getFirstName());
        } else {
            System.out.println("Insufficient funds for transfer");
        }
    }
}
