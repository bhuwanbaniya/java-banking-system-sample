package org.personal.banksystem.model.main.GUI;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
class ShadowButton extends JButton {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ShadowButton(String text, String imagePath) {
        super(text);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setHorizontalTextPosition(SwingConstants.CENTER);
        setVerticalTextPosition(SwingConstants.BOTTOM);
        setIcon(new ImageIcon(imagePath));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(Color.GRAY);
        g2.fillRoundRect(5, 5, getWidth() - 1, getHeight() - 1, 15, 15);
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
        g2.dispose();

        super.paintComponent(g);
    }

    @Override
    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
    }
}