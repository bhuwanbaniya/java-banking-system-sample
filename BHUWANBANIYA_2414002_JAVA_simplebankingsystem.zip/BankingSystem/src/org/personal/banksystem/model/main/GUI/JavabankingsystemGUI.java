package org.personal.banksystem.model.main.GUI;
//bhuwanbaniya2414002
import javax.swing.*;
import org.personal.banksystem.service.model.impl.ReadingAccount;
import org.personal.javabanksystem.model.Account;
import org.personal.javabanksystem.transaction.service.model.impl.Transactionserviceimpl;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class JavabankingsystemGUI {
    private JFrame frame;
    private LinkedList<Account> accountList;
    private JTextArea accountDetailsArea; // TextArea to display account details
    private JPanel accountDetailsPanel;    // Panel to show account details
    public JavabankingsystemGUI(LinkedList<Account> accountList) {
        this.accountList = accountList;
        initialize();
        showWelcomeMessage(); // Show the welcome message when the GUI initializes
    }

    private void initialize() {
        frame = new JFrame("Simple Banking System BBN");
        frame.setBounds(100, 100, 1200, 900); // Increased frame size
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null); // Use null layout for absolute positioning

        // Create and set the background image panel
        BackgroundPanel backgroundPanel = new BackgroundPanel("D:/image/bankbackground.jpg");
        backgroundPanel.setLayout(null); // Use null layout for absolute positioning
        backgroundPanel.setBounds(0, 0, frame.getWidth(), frame.getHeight());

        // Create and add the bank name label
        JLabel bankNameLabel = new JLabel("BHUWAN BANK NEPAL BBN");
        bankNameLabel.setFont(new Font("Arial", Font.BOLD, 50)); // Increased font size
        bankNameLabel.setForeground(new Color(0, 0, 128)); // Navy blue
        bankNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        bankNameLabel.setBounds(0, 20, frame.getWidth(), 60); // Adjusted size and position
        backgroundPanel.add(bankNameLabel);

        // Create and add buttons with specific positions and sizes
        JButton btnViewAccount = createButton("View Account Details", "D:/image/view_account.jpg", 50, 100);
        backgroundPanel.add(btnViewAccount);

        JButton btnDeposit = createButton("Deposit", "D:/image/deposit.png", 50, 260);
        backgroundPanel.add(btnDeposit);

        JButton btnWithdraw = createButton("Withdraw", "D:/image/withdraw.png", 50, 420);
        backgroundPanel.add(btnWithdraw);

        JButton btnTransfer = createButton("Transfer", "D:/image/transfer.png", 50, 580);
        backgroundPanel.add(btnTransfer);

        // Create and add a panel for contact information at the bottom
        JPanel contactPanel = new JPanel();
        contactPanel.setLayout(new GridLayout(2, 1)); // Grid layout with 2 rows, 1 column
        contactPanel.setBackground(Color.LIGHT_GRAY); // Light gray background
        contactPanel.setBounds(0, frame.getHeight() - 120, frame.getWidth(), 100); // Positioned at the bottom
        contactPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Padding

        // Create and add labels for contact information
        JLabel emailLabel = new JLabel("Email: support@bhuwanbanknepal.com");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        emailLabel.setForeground(Color.BLACK);
        emailLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel phoneLabel = new JLabel("Telephone: +977 1-1234567");
        phoneLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        phoneLabel.setForeground(Color.BLACK);
        phoneLabel.setHorizontalAlignment(SwingConstants.CENTER);

        contactPanel.add(emailLabel);
        contactPanel.add(phoneLabel);

        frame.add(contactPanel);

        // Create a smaller panel for the account details area, initially hidden
        accountDetailsPanel = new JPanel();
        accountDetailsPanel.setLayout(new BorderLayout());
        accountDetailsPanel.setBounds(frame.getWidth() - 320, 100, 300, 200); // Smaller size and positioned to the right
        accountDetailsPanel.setBorder(BorderFactory.createTitledBorder("Account Details")); // Title border
        accountDetailsPanel.setVisible(false); // Start hidden

        // Initialize the account details area
        accountDetailsArea = new JTextArea();
        accountDetailsArea.setEditable(false);
        accountDetailsArea.setFont(new Font("Arial", Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(accountDetailsArea); // Add scroll pane for better view
        accountDetailsPanel.add(scrollPane, BorderLayout.CENTER);

        // Add a close button to the panel
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.PLAIN, 14));
        closeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                accountDetailsPanel.setVisible(false); // Hide the panel when close button is clicked
            }
        });
        accountDetailsPanel.add(closeButton, BorderLayout.SOUTH); // Add close button to the bottom of the panel

        frame.add(accountDetailsPanel);

        // Add the background panel to the frame
        frame.add(backgroundPanel);

        // Ensure the frame is visible
        frame.setVisible(true);
    }

    private JButton createButton(String text, String iconPath, int x, int y) {
        JButton button = new ShadowButton(text, iconPath);
        customizeButton(button);
        button.setBounds(x, y, 500, 150); // Set size and position
        button.setPreferredSize(new Dimension(500, 150)); // Set preferred size

        // Add an action listener for the button
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (text.equals("View Account Details")) {
                    viewAccountDetails();
                } else if (text.equals("Deposit")) {
                    deposit();
                } else if (text.equals("Withdraw")) {
                    withdraw();
                } else if (text.equals("Transfer")) {
                    transfer();
                }
                showThankYouMessage(); // Show thank you message after an action
            }
        });
        return button;
    }

    private void customizeButton(JButton button) {
        button.setForeground(Color.WHITE); // Set text color to white for contrast
        button.setFont(button.getFont().deriveFont(Font.BOLD, 30f)); // Increased font size
        button.setBackground(Color.DARK_GRAY); // Set button background color for contrast
        button.setOpaque(true);
        button.setBorderPainted(false); // Remove border to blend with the background

        // Ensure the text is centered and visible
        button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setVerticalAlignment(SwingConstants.CENTER);
        button.setIconTextGap(20); // Adjust gap between icon and text

        // Adjust the icon size to fit well with the button size
        ImageIcon icon = (ImageIcon) button.getIcon();
        if (icon != null) {
            // Use a placeholder image to scale properly when button size is known
            Image image = icon.getImage();
            Image scaledImage = image.getScaledInstance(100, 100, Image.SCALE_SMOOTH); // Use fixed size for scaling
            button.setIcon(new ImageIcon(scaledImage));
        }
    }

    private void showWelcomeMessage() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel message = new JLabel("Welcome to BHUWAN BANK NEPAL BBN!");
        message.setFont(new Font("Arial", Font.BOLD, 20));
        message.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(message);

        // Optionally add an icon
        JLabel iconLabel = new JLabel(new ImageIcon("D:/image/welcome_icon.png")); // Placeholder path
        panel.add(iconLabel);

        JOptionPane.showConfirmDialog(frame, panel, "Welcome", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
    }

    private void showThankYouMessage() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel message = new JLabel("Thank you for using BHUWAN BANK NEPAL BBN!");
        message.setFont(new Font("Arial", Font.BOLD, 20));
        message.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(message);

        // Optionally add an icon
        JLabel iconLabel = new JLabel(new ImageIcon("D:/image/thank_you_icon.png")); // Placeholder path
        panel.add(iconLabel);

        JOptionPane.showConfirmDialog(frame, panel, "Thank You", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
    }

    private void viewAccountDetails() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr);
            Account account = findAccount(accountNumber);
            if (account != null) {
                // Display account details in the panel
                String details = "First Name: " + account.getFirstName() +
                                  "\nLast Name: " + account.getLastName() +
                                  "\nAccount Number: " + account.getAccountNumber() +
                                  "\nBalance: " + account.getBalance();
                accountDetailsArea.setText(details);
                accountDetailsPanel.setVisible(true); // Show panel
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found!");
                accountDetailsArea.setText(""); // Clear text area if account is not found
                accountDetailsPanel.setVisible(false); // Hide panel
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private void deposit() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr);
            Account account = findAccount(accountNumber);
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Deposit:");
                try {
                    int amount = Integer.parseInt(amountStr);
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!");
                    } else {
                        account.deposit(amount);
                        JOptionPane.showMessageDialog(frame, "Deposit Successful! New Balance: " + account.getBalance());
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found, try again!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private void withdraw() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        try {
            int accountNumber = Integer.parseInt(accountNumberStr);
            Account account = findAccount(accountNumber);
            if (account != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Withdraw:");
                try {
                    int amount = Integer.parseInt(amountStr);
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!");
                    } else if (account.getBalance() >= amount) {
                        account.withdraw(amount);
                        JOptionPane.showMessageDialog(frame, "Withdrawal Successful! New Balance: " + account.getBalance());
                    } else {
                        JOptionPane.showMessageDialog(frame, "Insufficient funds!");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found, try again!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private void transfer() {
        String sourceAccountNumberStr = JOptionPane.showInputDialog("Enter Source Account Number:");
        try {
            int sourceAccountNumber = Integer.parseInt(sourceAccountNumberStr);
            Account sourceAccount = findAccount(sourceAccountNumber);

            String destinationAccountNumberStr = JOptionPane.showInputDialog("Enter Destination Account Number:");
            int destinationAccountNumber = Integer.parseInt(destinationAccountNumberStr);
            Account destinationAccount = findAccount(destinationAccountNumber);

            if (sourceAccount != null && destinationAccount != null) {
                String amountStr = JOptionPane.showInputDialog("Enter Amount to Transfer:");
                try {
                    int amount = Integer.parseInt(amountStr);
                    if (amount < 0) {
                        JOptionPane.showMessageDialog(frame, "Amount cannot be negative!");
                    } else if (sourceAccount.getBalance() >= amount) {
                        Transactionserviceimpl.transfer(sourceAccount, destinationAccount, amount);
                        JOptionPane.showMessageDialog(frame, "Transfer Successful!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Insufficient funds in source account!");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid amount format!");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Account not found, try again!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid account number format!");
        }
    }

    private Account findAccount(int accountNumber) {
        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        String filePath = "src/Accounts.csv";
        ReadingAccount readingAccount = new ReadingAccount(filePath);
        LinkedList<Account> accountList = readingAccount.getAccounts();

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new JavabankingsystemGUI(accountList);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
