package org.personal.banksystem.service.model.impl;
//bhuwanbaniya2414002
import java.util.LinkedList;

import org.personal.javabanksystem.model.Account;

public class Main {
    public static void main(String[] args) {
        // Read accounts from CSV file
        String filePath = "src/Accounts.csv";
        ReadingAccount readingAccount = new ReadingAccount(filePath);
        LinkedList<Account> accountList = readingAccount.getAccounts();

        // Testing
        for (Account account : accountList) {
            System.out.println("First Name: " + account.getFirstName());
            System.out.println("Last Name: " + account.getLastName());
            System.out.println("Account Number: " + account.getAccountNumber());
            System.out.println("Balance: " + account.getBalance());
            System.out.println();
        }
    }
}