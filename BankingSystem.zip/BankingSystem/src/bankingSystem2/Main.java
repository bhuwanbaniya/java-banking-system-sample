package bankingSystem2;

import java.util.LinkedList;
import bankingSystem.Account;

public class Main {
    public static void main(String[] args) {
        // Read accounts from CSV file
        String filePath = "src/Accounts.csv";
        ReadAccounts readAccounts = new ReadAccounts(filePath);
        LinkedList<Account> accountList = readAccounts.getAccounts();

        // Testing
        for (Account account : accountList) {
            System.out.println("First Name: " + account.getFirstName());
            System.out.println("Last Name: " + account.getLastName());
            System.out.println("Account Number: " + account.getAccountNumber());
            System.out.println("Balance: " + account.getBalance());
            System.out.println();
        }
    }
}