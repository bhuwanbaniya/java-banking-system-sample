package bankingSystem2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import bankingSystem.Account;

public class ReadAccounts {
    private String filePath;

    // Constructor
    public ReadAccounts(String filePath) {
        this.filePath = filePath;
    }

    // Read CSV file and return account details
    public LinkedList<Account> getAccounts() {
        LinkedList<Account> accounts = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                String firstName = data[0];
                String lastName = data[1];
                int accountNumber = Integer.parseInt(data[2]);
                int balance = Integer.parseInt(data[3]);
                accounts.add(new Account(firstName, lastName, balance, accountNumber));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return accounts;
    }
}
