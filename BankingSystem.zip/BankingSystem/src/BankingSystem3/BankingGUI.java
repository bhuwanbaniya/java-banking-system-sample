package BankingSystem3;

import bankingSystem.Account;
import bankingSystem.Transaction;
import bankingSystem2.ReadAccounts;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class BankingGUI {
    private JFrame frame;
    private LinkedList<Account> accountList;

    public BankingGUI(LinkedList<Account> accountList) {
        this.accountList = accountList;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Banking System");
        frame.setBounds(100, 100, 500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel, BorderLayout.CENTER);
        panel.setLayout(new GridLayout(3, 2));

        JButton btnViewAccount = new JButton("View Account Details");
        btnViewAccount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewAccountDetails();
            }
        });
        panel.add(btnViewAccount);

        JButton btnDeposit = new JButton("Deposit");
        btnDeposit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deposit();
            }
        });
        panel.add(btnDeposit);

        JButton btnWithdraw = new JButton("Withdraw");
        btnWithdraw.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                withdraw();
            }
        });
        panel.add(btnWithdraw);

        JButton btnTransfer = new JButton("Transfer");
        btnTransfer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                transfer();
            }
        });
        panel.add(btnTransfer);

        frame.setVisible(true);
    }

    private void viewAccountDetails() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        int accountNumber = Integer.parseInt(accountNumberStr);
        Account account = findAccount(accountNumber);
        if (account != null) {
            JOptionPane.showMessageDialog(frame, "First Name: " + account.getFirstName() +
                    "\nLast Name: " + account.getLastName() +
                    "\nAccount Number: " + account.getAccountNumber() +
                    "\nBalance: " + account.getBalance());
        } else {
            JOptionPane.showMessageDialog(frame, "Account not found!");
        }
    }

    private void deposit() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        int accountNumber = Integer.parseInt(accountNumberStr);
        Account account = findAccount(accountNumber);
        if (account != null) {
            String amountStr = JOptionPane.showInputDialog("Enter Amount to Deposit:");
            int amount = Integer.parseInt(amountStr);
            account.deposit(amount);
            JOptionPane.showMessageDialog(frame, "Deposit Successful! New Balance: " + account.getBalance());
        } else {
            JOptionPane.showMessageDialog(frame, "Account not found!");
        }
    }

    private void withdraw() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter Account Number:");
        int accountNumber = Integer.parseInt(accountNumberStr);
        Account account = findAccount(accountNumber);
        if (account != null) {
            String amountStr = JOptionPane.showInputDialog("Enter Amount to Withdraw:");
            int amount = Integer.parseInt(amountStr);
            if (account.getBalance() >= amount) {
                account.withdraw(amount);
                JOptionPane.showMessageDialog(frame, "Withdrawal Successful! New Balance: " + account.getBalance());
            } else {
                JOptionPane.showMessageDialog(frame, "Insufficient funds!");
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Account not found!");
        }
    }

    private void transfer() {
        String sourceAccountNumberStr = JOptionPane.showInputDialog("Enter Source Account Number:");
        int sourceAccountNumber = Integer.parseInt(sourceAccountNumberStr);
        Account sourceAccount = findAccount(sourceAccountNumber);

        String destinationAccountNumberStr = JOptionPane.showInputDialog("Enter Destination Account Number:");
        int destinationAccountNumber = Integer.parseInt(destinationAccountNumberStr);
        Account destinationAccount = findAccount(destinationAccountNumber);

        if (sourceAccount != null && destinationAccount != null) {
            String amountStr = JOptionPane.showInputDialog("Enter Amount to Transfer:");
            int amount = Integer.parseInt(amountStr);
            if (sourceAccount.getBalance() >= amount) {
                Transaction.transfer(sourceAccount, destinationAccount, amount);
                JOptionPane.showMessageDialog(frame, "Transfer Successful!");
            } else {
                JOptionPane.showMessageDialog(frame, "Insufficient funds in source account!");
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Account not found!");
        }
    }

    private Account findAccount(int accountNumber) {
        for (Account account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        String filePath = "src/Accounts.csv";
        ReadAccounts readAccounts = new ReadAccounts(filePath);
        LinkedList<Account> accountList = readAccounts.getAccounts();

        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    BankingGUI window = new BankingGUI(accountList);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
