/**
 * 
 */
/**
 * @author Bichoy Emad
 *
 */
module BankManagementSystem {
	requires java.desktop;
}